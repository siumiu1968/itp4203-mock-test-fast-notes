package com.example.mocktestanswer

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CameraDao {

    @Query("SELECT * FROM camera_table")
    fun getAllCameras(): List<Camera>

    @Query("SELECT * FROM camera_table WHERE id = :id LIMIT 1")
    fun getCameraById(id: String): Camera?

    @Insert
    fun insertCamera(camera: Camera)
}
